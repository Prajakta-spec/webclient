package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentsNotFoundException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyClientException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyServerException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.EnvoyRetrieveService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.activation.MimetypesFileTypeMap;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Positive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaRetrieveContentController {
  private static final Logger LOGGER =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller.LoaRetrieveContentController.class);

  private final RequestTracker requestTracker;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  private final EnvoyRetrieveService envoyRetrieveService;

  public LoaRetrieveContentController(
      RequestTracker requestTracker,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      EnvoyRetrieveService envoyRetrieveService) {
    this.requestTracker = requestTracker;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.envoyRetrieveService = envoyRetrieveService;
  }

  @GetMapping(
      path =
          Constants.LOA_ID_DYNAMIC_PATH_PARAMETER
              + "/documents/"
              + Constants.UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER)
  @Operation(
      summary = "Retrieve Loa document by uniqueDocId",
      description = "Retrieve an Loa document by loaId and uniqueDocId",
      method = "GET",
      tags = {"Loa Document Content"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Loa Document",
            content = @Content(mediaType = MediaType.APPLICATION_OCTET_STREAM_VALUE)),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access Loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<Resource> getDocumentContentByUniqueDocId(
      @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @Positive(message = Constants.LOA_ID_GREATER_THAN_ZERO_MSG)
          @Max(value = Integer.MAX_VALUE, message = Constants.LOA_ID_NOT_VALID_INTEGER_MSG)
          Integer loaId,
      @PathVariable(value = Constants.UNIQUE_DOC_ID_PATH_PARAMETER) String uniqueDocId)
      throws DocumentsNotFoundException, EnvoyClientException, EnvoyServerException {
    String trackingId = requestTracker.getTrackingId();
    LOGGER.info(
        "{} - Enter LoaRetrieveContentController.getDocumentContentByUniqueDocId()"
            + " - loaId: {} and uniqueDocId: {}",
        trackingId,
        loaId,
        uniqueDocId);

    HttpStatus httpStatus = HttpStatus.OK;
    Resource resource;
    MultiValueMap<String, String> loaRetrieveContentResponseHeader;

    Optional<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> loaMetadataOptional =
        loaUniqueDocumentIdRepository.findById(uniqueDocId);

    if (loaMetadataOptional.isPresent()) {
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata = loaMetadataOptional.get();
      if (loaId.equals(loaMetadata.getLoaId())) {
        resource = envoyRetrieveService.retrieveLoaDocuments(trackingId, uniqueDocId);
        loaRetrieveContentResponseHeader =
            getRetrieveContentResponseHeader(loaMetadata.getDocumentName());
      } else {
        LOGGER.error(
            "{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
            trackingId,
            uniqueDocId,
            loaId);
        throw new DocumentsNotFoundException(
            HttpStatus.NOT_FOUND,
            "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
      }
    } else {
      LOGGER.error(
          "{} - DocumentsNotFoundException: No documents found for uniqueDocId: {} and loaId: {}",
          trackingId,
          uniqueDocId,
          loaId);
      throw new DocumentsNotFoundException(
          HttpStatus.NOT_FOUND,
          "No documents found for uniqueDocId: " + uniqueDocId + " and loaId: " + loaId);
    }

    LOGGER.info(
        "{} - Exit LoaRetrieveContentController.getDocumentContentByUniqueDocId()", trackingId);
    return new ResponseEntity<>(resource, loaRetrieveContentResponseHeader, httpStatus);
  }

  private MultiValueMap<String, String> getRetrieveContentResponseHeader(String documentName) {
    MimetypesFileTypeMap fileTypeMap = new MimetypesFileTypeMap();
    String contentType = fileTypeMap.getContentType(documentName);
    LOGGER.info("{} - Content Type is: {}", requestTracker.getTrackingId(), contentType);
    MultiValueMap<String, String> loaRetrieveContentResponseHeader =
        new LinkedMultiValueMap<>();
    String documentNameWithDoubleQuotes = "\"" + documentName + "\"";
    LOGGER.info("documentNameWithDoubleQuotes is -{}", documentNameWithDoubleQuotes);
    loaRetrieveContentResponseHeader.add(
        HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + documentNameWithDoubleQuotes);
    loaRetrieveContentResponseHeader.add(HttpHeaders.CONTENT_TYPE, contentType);
    loaRetrieveContentResponseHeader.add(
        HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
    return loaRetrieveContentResponseHeader;
  }
}
