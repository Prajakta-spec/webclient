package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.UniqueDocIdMetadataResponse;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.retreive.UniqueDocIdMetadataSuccessResponseData;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.DocumentsNotFoundException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidCategorySubCategoryException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidDocumentException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.InvalidWbUserIdException;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.Objects;
import java.util.Optional;

@RestController
@Validated
@RequestMapping(
    path = Constants.LOA_METADATA_BASE_ENDPOINT,
    produces = MediaType.APPLICATION_JSON_VALUE)
public class LoaUpdateMetadataController {

  private static final Logger LOGGER =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.controller.LoaUpdateMetadataController.class);

  private final RequestTracker requestTracker;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository;

  private final com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService;

  public LoaUpdateMetadataController(
      RequestTracker requestTracker,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.repository.LoaUniqueDocumentIdRepository loaUniqueDocumentIdRepository,
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.LoaMetadataService loaMetadataService) {
    this.requestTracker = requestTracker;
    this.loaUniqueDocumentIdRepository = loaUniqueDocumentIdRepository;
    this.loaMetadataService = loaMetadataService;
  }

  @PatchMapping(
      path =
          Constants.LOA_ID_DYNAMIC_PATH_PARAMETER
              + "/document-metadata/"
              + Constants.UNIQUE_DOC_ID_DYNAMIC_PATH_PARAMETER,
      consumes = MediaType.APPLICATION_JSON_VALUE)
  @Operation(
      summary = "Update loa document metadata by uniqueDocId",
      description = "Update loa document metadata for a given loa by uniqueDocId",
      method = "PATCH",
      tags = {"Loa Document Metadata"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Loa document metadata after update",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = UniqueDocIdMetadataResponse.class))),
        @ApiResponse(
            responseCode = "400",
            description = "Bad Request",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "403",
            description = "Not Authorized to access loa document management API",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "404",
            description = "Document not found",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class))),
        @ApiResponse(
            responseCode = "500",
            description = "Internal Server Error",
            content =
                @Content(
                    mediaType = MediaType.APPLICATION_JSON_VALUE,
                    schema = @Schema(implementation = com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse.class)))
      })
  public ResponseEntity<UniqueDocIdMetadataResponse> updateLoaMetadataByUniqueDocId(
      @Validated @RequestBody com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.update.LoaPatchMetadata loaPatchMetadata,
      @PathVariable(value = Constants.LOA_ID_PATH_PARAMETER)
          @NotNull(message = Constants.LOA_ID_REQUIRED_MSG)
          @Positive(message = Constants.LOA_ID_GREATER_THAN_ZERO_MSG)
          @Max(value = Integer.MAX_VALUE, message = Constants.LOA_ID_NOT_VALID_INTEGER_MSG)
          Integer loaId,
      @PathVariable(value = Constants.UNIQUE_DOC_ID_PATH_PARAMETER) String uniqueDocId)
      throws DocumentsNotFoundException,
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException,
          com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException,
          InvalidCategorySubCategoryException,
          InvalidDocumentException,
          InvalidWbUserIdException {
    String trackingId = requestTracker.getTrackingId();

    boolean isUpdateNeeded = false;
    if (Objects.nonNull(loaPatchMetadata)
        && loaPatchMetadata.getSubCategoryId() != null
        && (Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_10.equals(
                loaPatchMetadata.getSubCategoryId())
            || Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_11.equals(
                loaPatchMetadata.getSubCategoryId()))) {
      LOGGER.error(
          "{} - InvalidDocumentException: Documents cannot be updated for the sub category 10(Agency Statements) and 11(DB Commission statements)}",
          trackingId);
      throw new InvalidDocumentException(
          HttpStatus.BAD_REQUEST,
          "Documents cannot be updated for the sub category 10(Agency Statements) and 11(DB Commission statements)");
    }
    Optional<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata> optionalLoaMetadata =
        loaUniqueDocumentIdRepository.findById(uniqueDocId);
    if (optionalLoaMetadata.isPresent()) {
      com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata = optionalLoaMetadata.get();
      if (loaPatchMetadata.getPaymentDate() != null
          || loaPatchMetadata.getCheckEftNum() != null
          || loaPatchMetadata.getReissue() != null) {
        LOGGER.error(
            "{} - InvalidDocumentException: Documents cannot be updated for the given attributes}",
            trackingId);
        throw new InvalidDocumentException(
            HttpStatus.BAD_REQUEST, "Documents cannot be updated for the  given attributes");
      }
      if (!loaId.equals(loaMetadata.getLoaId())) {
        LOGGER.error(
            "{} - DocumentsNotFoundException: Document not found for the given loa {}",
            trackingId,
            loaId);
        throw new DocumentsNotFoundException(
            HttpStatus.NOT_FOUND, "Document not found for the given loa " + loaId);
      }

      if (loaPatchMetadata.getDocumentName() != null
          && loaMetadataService.isInvalidDocumentName(loaPatchMetadata.getDocumentName())) {
        LOGGER.error(
            "{} - InvalidDocumentException: Document name {} is not valid",
            trackingId,
            loaPatchMetadata.getDocumentName());
        throw new InvalidDocumentException(
            HttpStatus.BAD_REQUEST,
            "Document name " + loaPatchMetadata.getDocumentName() + " is not valid");
      }

      if (loaPatchMetadata.getDocumentName() != null
          && loaPatchMetadata.getDocumentName().trim().isEmpty()) {
        LOGGER.error(
            "{} - InvalidDocumentException: Document name {} cannot be empty",
            trackingId,
            loaPatchMetadata.getDocumentName());
        throw new InvalidDocumentException(HttpStatus.BAD_REQUEST, "Document name cannot be empty");
      }

      Integer categoryIdToValidate;
      Integer subCategoryIdToValidate;

      Integer existingCategoryId = loaMetadata.getCategoryId();
      Integer existingSubCategoryId = loaMetadata.getSubCategoryId();

      if (Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_10.equals(existingSubCategoryId)
          || Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_11.equals(existingSubCategoryId)) {
        LOGGER.error(
            "{} - InvalidDocumentException: Documents cannot be updated for the sub category 10(Agency Statements) and 11(DB Commission statements)}",
            trackingId);
        throw new InvalidDocumentException(
            HttpStatus.BAD_REQUEST,
            "Documents cannot be updated for the sub category 10(Agency Statements) and 11(DB Commission statements)");
      }

      if (loaPatchMetadata.getCategoryId() != null
          || loaPatchMetadata.getSubCategoryId() != null) {
        categoryIdToValidate =
            loaPatchMetadata.getCategoryId() == null
                ? existingCategoryId
                : loaPatchMetadata.getCategoryId();
        subCategoryIdToValidate =
            loaPatchMetadata.getSubCategoryId() == null
                ? existingSubCategoryId
                : loaPatchMetadata.getSubCategoryId();

        if (!loaMetadataService.isValidCategorySubCategoryCombination(
            categoryIdToValidate, subCategoryIdToValidate, requestTracker.getOpaqueBearerToken())) {
          LOGGER.error(
              "{} - InvalidCategorySubCategoryException: Invalid Category and Sub Category combination",
              trackingId);
          throw new InvalidCategorySubCategoryException(
              HttpStatus.BAD_REQUEST,
              "categoryId: "
                  + categoryIdToValidate
                  + ", subCategoryId: "
                  + subCategoryIdToValidate
                  + " - Invalid Category and Sub Category combination");
        }
      }
      if (loaPatchMetadata.getDocumentName() != null) {
        Optional<String> newFileNameExtension =
            getDocumentExtension(loaPatchMetadata.getDocumentName());
        if (newFileNameExtension.isPresent()) {
          if (!newFileNameExtension.get().equals(loaMetadata.getDocumentExtension())) {
            LOGGER.error(
                "{} - InvalidDocumentException: Document Extension cannot be updated", trackingId);
            throw new InvalidDocumentException(
                HttpStatus.BAD_REQUEST, "Document Extension cannot be updated");
          } else {
            loaMetadata.setDocumentName(loaPatchMetadata.getDocumentName());
          }
        } else {
          LOGGER.error(
              "{} - InvalidDocumentException: Document {} does not have an extension",
              trackingId,
              loaPatchMetadata.getDocumentName());
          throw new InvalidDocumentException(
              HttpStatus.BAD_REQUEST,
              "Unsupported Document: Document "
                  + loaPatchMetadata.getDocumentName()
                  + " does not have an extension");
        }
      }

      if (loaPatchMetadata.getCategoryId() != null) {
        isUpdateNeeded = true;
        loaMetadata.setCategoryId(loaPatchMetadata.getCategoryId());
      }
      if (loaPatchMetadata.getSubCategoryId() != null) {
        isUpdateNeeded = true;
        loaMetadata.setSubCategoryId(loaPatchMetadata.getSubCategoryId());
      }
      Integer wbUserId = loaPatchMetadata.getWbUserId();
      String verifiedWbUserId = null;
      if (wbUserId == null) {
        verifiedWbUserId = loaMetadataService.returnDefaultWbUserIdIfWbUserIdNull();
      } else if (loaMetadataService.isValidWbUserId(wbUserId.toString())) {
        verifiedWbUserId = wbUserId.toString();
      }
      if (verifiedWbUserId != null) {
        loaMetadata.setUpdatedById(Integer.valueOf(verifiedWbUserId));
      }

      if (loaPatchMetadata.getReceivedDate() != null) {
        isUpdateNeeded = true;
        loaMetadata.setReceivedDate(loaPatchMetadata.getReceivedDate());
      }
      if (loaPatchMetadata.getPaymentDate() != null) {
        isUpdateNeeded = true;
        loaMetadata.setPaymentDate(loaPatchMetadata.getPaymentDate());
      }
      if (loaPatchMetadata.getNotes() != null) {
        isUpdateNeeded = true;
        loaMetadata.setNotes(loaPatchMetadata.getNotes());
      }
      if (loaPatchMetadata.getCheckEftNum() != null) {
        isUpdateNeeded = true;
        loaMetadata.setCheckEftNum(loaPatchMetadata.getCheckEftNum());
      }
      if (loaPatchMetadata.getNppi() != null) {
        isUpdateNeeded = true;
        loaMetadata.setNppi(loaPatchMetadata.getNppi());
      }
      if (loaPatchMetadata.getReissue() != null) {
        isUpdateNeeded = true;
        loaMetadata.setReissue(loaPatchMetadata.getReissue());
      }
      if (isUpdateNeeded) {
        loaMetadata.setUpdatedAt(new Date());
        loaUniqueDocumentIdRepository.save(loaMetadata);
      } else {
        LOGGER.info(
            "{} - No updated needed. Content to patch matches existing content", trackingId);
      }

      UniqueDocIdMetadataResponse uniqueDocIdMetadataResponse = new UniqueDocIdMetadataResponse();
      uniqueDocIdMetadataResponse.setTrackingId(trackingId);
      UniqueDocIdMetadataSuccessResponseData uniqueDocIdMetadataSuccessResponseData =
          new UniqueDocIdMetadataSuccessResponseData();
      uniqueDocIdMetadataSuccessResponseData.setLoaMetadata(loaMetadata);
      uniqueDocIdMetadataResponse.setData(uniqueDocIdMetadataSuccessResponseData);
      LOGGER.info(
          "{} - Exit LoaUpdateMetadataController.updateLoaMetadataByUniqueDocId()",
          trackingId);
      return new ResponseEntity<>(uniqueDocIdMetadataResponse, HttpStatus.OK);

    } else {
      LOGGER.error(
          "{} - DocumentsNotFoundException: No documents found for given uniqueDocId:{} and loaId:{}",
          trackingId,
          uniqueDocId,
          loaId);
      throw new DocumentsNotFoundException(
          HttpStatus.NOT_FOUND,
          "No documents found for given uniqueDocId: "
              + uniqueDocId
              + " and loaId: "
              + loaId);
    }
  }

  private static Optional<String> getDocumentExtension(String documentName) {
    return Optional.ofNullable(documentName)
        .filter(f -> f.contains("."))
        .map(f -> f.substring(documentName.lastIndexOf('.') + 1));
  }
}