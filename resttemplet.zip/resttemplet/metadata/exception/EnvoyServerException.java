package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class EnvoyServerException extends Exception {

  private final HttpStatus httpStatusCode;

  public EnvoyServerException(HttpStatus httpStatusCode, String message) {
    super(message);
    this.httpStatusCode = httpStatusCode;
  }
}