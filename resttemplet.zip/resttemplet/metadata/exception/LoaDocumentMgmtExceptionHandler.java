package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.RequestTracker;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.Error;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.ErrorResponseData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindingResult;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.HandlerMapping;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@ControllerAdvice
public class LoaDocumentMgmtExceptionHandler {

    private static final Logger loaDocumentMgmtExceptionHandlerLogger =
            LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.LoaDocumentMgmtExceptionHandler.class);

    private final RequestTracker requestTracker;

    public LoaDocumentMgmtExceptionHandler(RequestTracker requestTracker) {
        this.requestTracker = requestTracker;
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleConstraintValidationException(ConstraintViolationException constraintViolationException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught ConstraintViolationException with a message {}",
                requestTracker.getTrackingId(), constraintViolationException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        ErrorResponseData errorResponseData = new ErrorResponseData();
        List<Error> errorList = new ArrayList<>();
        for (ConstraintViolation<?> constraintViolation : constraintViolationException.getConstraintViolations()) {
            String message = constraintViolation.getMessage();
            Error error = new Error();
            error.setCode(HttpStatus.BAD_REQUEST.value());
            error.setMessage("ConstraintViolationException thrown with the message: " + message);
            error.setReason(message);
            errorList.add(error);
        }

        errorResponseData.setErrors(errorList);
        loaDocumentMgmtErrorResponse.setErrors(errorResponseData);
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingServletRequestPartException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleMissingServletRequestPartException(MissingServletRequestPartException missingServletRequestPartException) {
        loaDocumentMgmtExceptionHandlerLogger.
                error("{} - Caught MissingServletRequestPartException with a message {}",
                        requestTracker.getTrackingId(), missingServletRequestPartException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        String message = missingServletRequestPartException.getMessage();
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(HttpStatus.BAD_REQUEST.value(),
                "MissingServletRequestPartException thrown with the message: " + message, message));
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleInvalidFormatException(HttpMessageNotReadableException httpMessageNotReadableException) {
        loaDocumentMgmtExceptionHandlerLogger.
                error("{} - Caught InvalidFormatException with a message {}",
                        requestTracker.getTrackingId(), httpMessageNotReadableException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        String message = httpMessageNotReadableException.getMessage();
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(HttpStatus.BAD_REQUEST.value(),
                "InvalidFormatException thrown with the message: " + message, message));
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleMethodArgumentNotValidException(MethodArgumentNotValidException methodArgumentNotValidException) {
        loaDocumentMgmtExceptionHandlerLogger.
                error("{} - Caught MethodArgumentNotValidException with a message {}",
                        requestTracker.getTrackingId(), methodArgumentNotValidException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        BindingResult bindingResult = methodArgumentNotValidException.getBindingResult();
        ErrorResponseData errorResponseData = new ErrorResponseData();
        List<Error> errorList = new ArrayList<>();
        bindingResult.getAllErrors().forEach(objectError -> {
            String message = objectError.getDefaultMessage();
            Error error = new Error();
            error.setCode(HttpStatus.BAD_REQUEST.value());
            error.setMessage("MethodArgumentNotValidException thrown with the message: " + message);
            error.setReason(message);
            errorList.add(error);
        });
        errorResponseData.setErrors(errorList);
        loaDocumentMgmtErrorResponse.setErrors(errorResponseData);
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleMissingServletRequestPartException(MissingServletRequestParameterException missingServletRequestParameterException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught MissingServletRequestParameterException with a message {}",
                requestTracker.getTrackingId(), missingServletRequestParameterException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        String message = missingServletRequestParameterException.getMessage();
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(HttpStatus.BAD_REQUEST.value(),
                "MissingServletRequestParameterException thrown with the message: " + message, message));
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NumberFormatException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleNumberFormatException(NumberFormatException numberFormatException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught NumberFormatException with a message {}",
                requestTracker.getTrackingId(), numberFormatException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        String message = numberFormatException.getMessage();
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(HttpStatus.BAD_REQUEST.value(),
                "NumberFormatException thrown with the message: " + message, message));
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleMissingRequestHeaderException(MissingRequestHeaderException missingRequestHeaderException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught MissingRequestHeaderException with a message {}",
                requestTracker.getTrackingId(), missingRequestHeaderException.getMessage());
        String reason = "Missing request header: " + missingRequestHeaderException.getHeaderName() + " of type " +
                missingRequestHeaderException.getParameter().getParameterType().getSimpleName();
        String message = "MissingRequestHeaderException thrown: " + reason;
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(HttpStatus.BAD_REQUEST.value(), message, reason),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(DocumentMetadataAlreadyExistException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleDocumentMetadataAlreadyExistException(DocumentMetadataAlreadyExistException documentMetadataAlreadyExistException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught documentMetadataAlreadyExistException with a message {}",
                requestTracker.getTrackingId(), documentMetadataAlreadyExistException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        String message = documentMetadataAlreadyExistException.getMessage();
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(HttpStatus.BAD_REQUEST.value(),
                "documentMetadataAlreadyExistException thrown with the message: " + message, message));
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MissingUniqueDocIdException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleMissingUniqueDocIdException(MissingUniqueDocIdException missingUniqueDocIdException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught missingUniqueDocIdException with a message {}",
                requestTracker.getTrackingId(), missingUniqueDocIdException.getMessage());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        String message = missingUniqueDocIdException.getMessage();
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(HttpStatus.BAD_REQUEST.value(),
                "missingUniqueDocIdException thrown with the message: " + message, message));
        return new ResponseEntity<>(loaDocumentMgmtErrorResponse, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse> handleMissingRequestHeaderException(
            MethodArgumentTypeMismatchException methodArgumentTypeMismatchException) {
        loaDocumentMgmtExceptionHandlerLogger.
                error("{} - Caught MethodArgumentTypeMismatchException with a message {}", requestTracker.getTrackingId(),
                        methodArgumentTypeMismatchException.getMessage());
        String reason = methodArgumentTypeMismatchException.getParameter().getParameterName()
                + " path parameter type mismatch. Not a valid path parameter.";
        String message = "MethodArgumentTypeMismatchException thrown: " + methodArgumentTypeMismatchException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(HttpStatus.BAD_REQUEST.value(), message, reason),
                HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(EnvoyClientException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse> handleEnvoyClientException(EnvoyClientException envoyClientException,
                                                                                                                                                                         ServletWebRequest servletWebRequest) {
        Map pathParametersMap = (Map) servletWebRequest.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE,
                RequestAttributes.SCOPE_REQUEST);
        String loaId = (String) Objects.requireNonNull(pathParametersMap).get(Constants.LOA_ID_PATH_PARAMETER);
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught EnvoyClientException for loa-id: {} " +
                        Constants.LOGGER_MESSAGE_STATUS_CODE_AND_MESSAGE,
                requestTracker.getTrackingId(), loaId,
                envoyClientException.getHttpStatusCode(),
                envoyClientException.getMessage());
        String reason = envoyClientException.getMessage();
        String message = "EnvoyClientException: " + envoyClientException.getMessage();
        return new ResponseEntity<>(
                getLoaDocumentMmgtErrorResponse(envoyClientException.getHttpStatusCode().value(), message,
                        reason),
                envoyClientException.getHttpStatusCode());
    }

    @ExceptionHandler(EnvoyServerException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse> handleEnvoyServerException(EnvoyServerException envoyServerException,
                                                                                                                                                                         ServletWebRequest servletWebRequest) {
        Map pathParametersMap = (Map) servletWebRequest.getAttribute(HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE,
                RequestAttributes.SCOPE_REQUEST);
        String loaId = (String) Objects.requireNonNull(pathParametersMap).get(Constants.LOA_ID_PATH_PARAMETER);
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught EnvoyServerException for loa-id: {} " +
                        Constants.LOGGER_MESSAGE_STATUS_CODE_AND_MESSAGE,
                requestTracker.getTrackingId(), loaId,
                envoyServerException.getHttpStatusCode(),
                envoyServerException.getMessage());
        String reason = envoyServerException.getMessage();
        String message = "EnvoyServerException: "
                + envoyServerException.getMessage();
        return new ResponseEntity<>(
                getLoaDocumentMmgtErrorResponse(envoyServerException.getHttpStatusCode().value(), message,
                        reason),
                envoyServerException.getHttpStatusCode());
    }

    @ExceptionHandler(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse> handleDocumentCategoriesClientException(
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException loaDocumentCategoriesClientException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught DocumentCategoriesClientException " +
                        Constants.LOGGER_MESSAGE_STATUS_CODE_AND_MESSAGE,
                requestTracker.getTrackingId(),
                loaDocumentCategoriesClientException.getHttpStatusCode(),
                loaDocumentCategoriesClientException.getMessage());
        String reason = loaDocumentCategoriesClientException.getMessage();
        String message = "DocumentCategoriesClientException: "
                + loaDocumentCategoriesClientException.getMessage();
        return new ResponseEntity<>(
                getLoaDocumentMmgtErrorResponse(loaDocumentCategoriesClientException.getHttpStatusCode().value(),
                        message, reason),
                loaDocumentCategoriesClientException.getHttpStatusCode());
    }

    @ExceptionHandler(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse> handleDocumentCategoriesServerException(
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesServerException loaDocumentCategoriesServerException,
            ServletWebRequest servletWebRequest) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught DocumentCategoriesServerException " +
                        Constants.LOGGER_MESSAGE_STATUS_CODE_AND_MESSAGE,
                requestTracker.getTrackingId(),
                loaDocumentCategoriesServerException.getHttpStatusCode(),
                loaDocumentCategoriesServerException.getMessage());
        String reason = loaDocumentCategoriesServerException.getMessage();
        String message = "DocumentCategoriesServerException: "
                + loaDocumentCategoriesServerException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(loaDocumentCategoriesServerException.
                getHttpStatusCode().value(), message, reason),
                loaDocumentCategoriesServerException.getHttpStatusCode());
    }

    @ExceptionHandler(DocumentsNotFoundException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleJsonProcessingException(DocumentsNotFoundException documentsNotFoundException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught DocumentsNotFoundException for with a message {}",
                requestTracker.getTrackingId(),
                documentsNotFoundException.getMessage());
        String reason = documentsNotFoundException.getMessage();
        String message = "DocumentsNotFoundException thrown: " + documentsNotFoundException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(documentsNotFoundException
                .getHttpStatusCode().value(), message, reason), documentsNotFoundException.getHttpStatusCode());
    }

    @ExceptionHandler(InvalidDocumentException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleInvalidDocumentException(InvalidDocumentException invalidDocumentException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught InvalidDocumentException for with a message {}",
                requestTracker.getTrackingId(),
                invalidDocumentException.getMessage());
        String reason = invalidDocumentException.getMessage();
        String message = "InvalidDocumentException thrown: " + invalidDocumentException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(invalidDocumentException
                .getHttpStatusCode().value(), message, reason), invalidDocumentException.getHttpStatusCode());
    }

    @ExceptionHandler(InvalidCategorySubCategoryException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleInvalidCategorySubCategoryException(InvalidCategorySubCategoryException invalidCategorySubCategoryException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught InvalidCategorySubCategoryException for with a message {}",
                requestTracker.getTrackingId(),
                invalidCategorySubCategoryException.getMessage());
        String reason = invalidCategorySubCategoryException.getMessage();
        String message = "InvalidCategorySubCategoryException thrown: " + invalidCategorySubCategoryException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(invalidCategorySubCategoryException
                .getHttpStatusCode().value(), message, reason), invalidCategorySubCategoryException.getHttpStatusCode());
    }

    @ExceptionHandler(InvalidIsoAlpha3CountryCodeException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleInvalidIsoAlpha3CountryCodeException(InvalidIsoAlpha3CountryCodeException invalidIsoAlpha3CountryCodeException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught InvalidIsoAlpha3CountryCodeException for with a message {}",
                requestTracker.getTrackingId(),
                invalidIsoAlpha3CountryCodeException.getMessage());
        String reason = invalidIsoAlpha3CountryCodeException.getMessage();
        String message = "InvalidIsoAlpha3CountryCodeException thrown: " + invalidIsoAlpha3CountryCodeException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(invalidIsoAlpha3CountryCodeException
                .getHttpStatusCode().value(), message, reason), invalidIsoAlpha3CountryCodeException.getHttpStatusCode());
    }

    @ExceptionHandler(InvalidWbCountryCodeException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleInvalidWbCountryCodeException(InvalidWbCountryCodeException invalidWbCountryCodeException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught InvalidWbCountryCodeException for with a message {}",
                requestTracker.getTrackingId(),
                invalidWbCountryCodeException.getMessage());
        String reason = invalidWbCountryCodeException.getMessage();
        String message = "InvalidWbCountryCodeException thrown: " + invalidWbCountryCodeException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(invalidWbCountryCodeException
                .getHttpStatusCode().value(), message, reason), invalidWbCountryCodeException.getHttpStatusCode());
    }

    @ExceptionHandler(InvalidWbUserIdException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleInvalidWbUserIdException(InvalidWbUserIdException invalidWbUserIdException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught InvalidWbUserIdException for with a message {}",
                requestTracker.getTrackingId(),
                invalidWbUserIdException.getMessage());
        String reason = invalidWbUserIdException.getMessage();
        String message = "InvalidWbUserIdException thrown: " + invalidWbUserIdException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(invalidWbUserIdException
                .getHttpStatusCode().value(), message, reason), invalidWbUserIdException.getHttpStatusCode());
    }

    @ExceptionHandler(JsonProcessingException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleJsonProcessingException(JsonProcessingException jsonProcessingException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught JsonProcessingException for with a message {}",
                requestTracker.getTrackingId(),
                jsonProcessingException.getMessage());
        String reason = jsonProcessingException.getMessage();
        String message = "JsonProcessingException thrown: " + jsonProcessingException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR.value(), message,
                reason), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse>
    handleHttpMediaTypeNotSupportedException(HttpMediaTypeNotSupportedException httpMediaTypeNotSupportedException) {
        loaDocumentMgmtExceptionHandlerLogger.error("{} - Caught HttpMediaTypeNotSupportedException for with a message {}",
                requestTracker.getTrackingId(), httpMediaTypeNotSupportedException.getMessage());
        String reason = httpMediaTypeNotSupportedException.getMessage();
        String message = "HttpMediaTypeNotSupportedException thrown: " + httpMediaTypeNotSupportedException.getMessage();
        return new ResponseEntity<>(getLoaDocumentMmgtErrorResponse(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value(), message,
                reason), HttpStatus.UNSUPPORTED_MEDIA_TYPE);
    }

    private com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse getLoaDocumentMmgtErrorResponse(Integer statusCode,
                                                                                                                                                                   String errorMessage,
                                                                                                                                                                   String errorReason) {
        loaDocumentMgmtExceptionHandlerLogger.info("{} - Enter LoaDocumentMgmtExceptionHandler" +
                ".getLoaDocumentMetadataErrorResponse()", requestTracker.getTrackingId());
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse loaDocumentMgmtErrorResponse = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.error.LoaDocumentMgmtErrorResponse();
        loaDocumentMgmtErrorResponse.setTrackingId(requestTracker.getTrackingId());
        loaDocumentMgmtErrorResponse.setErrors(getLoaDocumentMgmtErrorResponseData(statusCode, errorMessage, errorReason));
        loaDocumentMgmtExceptionHandlerLogger.info("{} - Exit LoaDocumentMgmtExceptionHandler.getLoaDocumentMetadataErrorResponse()",
                requestTracker.getTrackingId());
        return loaDocumentMgmtErrorResponse;
    }

    private static ErrorResponseData getLoaDocumentMgmtErrorResponseData(Integer statusCode,
                                                                            String errorMessage,
                                                                            String errorReason) {
        ErrorResponseData errorResponseData = new ErrorResponseData();
        List<Error> errorList = new ArrayList<>();
        Error error = new Error();
        error.setCode(statusCode);
        error.setMessage(errorMessage);
        error.setReason(errorReason);
        errorList.add(error);
        errorResponseData.setErrors(errorList);
        return errorResponseData;
    }
}
