package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.config.local;

import com.amazonaws.services.dynamodbv2.AmazonDynamoDB;
import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBMapper;
import com.amazonaws.services.dynamodbv2.model.*;
import com.amazonaws.services.dynamodbv2.util.TableUtils;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.entity.WbCountry;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.local.LocalCountries;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.countries.repository.CountriesRepository;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.entity.WbUser;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.local.LocalWbUsers;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.repository.WbUsersRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;
import java.util.Objects;
import java.util.Optional;

@Slf4j
@Component
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.LOCAL_DOCKER_ENVIRONMENT,
  Constants.INTEGRATION_TEST_ENVIRONMENT
})
public class InitializeLocal implements CommandLineRunner {
  private final AmazonDynamoDB amazonDynamoDB;

  private final DynamoDBMapper dynamoDBMapper;

  private final RestTemplate localDocMgmtRestTemplate;

  private final Environment environment;
  private final CountriesRepository countriesRepository;
  private final WbUsersRepository wbUsersRepository;

  @Value("classpath:local-wb-countries/local-wb-countries.json")
  private Resource localWbOfficesDataJsonFile;

  @Value("${document.management.default-wb-user}")
  private String documentManagementDefaultWbUser;

  @Value("classpath:local-wb-all-users/local-wb-all-users.json")
  private Resource localWbUsersDataJsonFile;

  @Value("${dynamodb.environment.prefix}")
  private String dynamoDBPrefix;

  @Value("classpath:local-documents/file-example_PDF_1MB.pdf")
  private Resource loaDocumentPdfDocument;

  @Value("classpath:local-documents/file_example_PPT_1MB.ppt")
  private Resource loaDocumentPptDocument;

  @Value("classpath:local-documents/plan-750487342-JOB1-5.txt")
  private Resource loaDocumentTxtDocument;

  @Value("classpath:local-documents/pptx2.pptx")
  private Resource loaDocumentPptxDocument;

  @Value("classpath:local-documents/sample-doc-file-for-testing.docx")
  private Resource loaDocumentDocxDocument;

  @Value("classpath:local-documents/sample-doc-file-for-testing-1.doc")
  private Resource loaDocumentDocDocument;

  @Value("classpath:local-documents/Environment Plan.xlsx")
  private Resource loaDocumentXlsxDocument;

  @Value("classpath:local-documents/Environment.xls")
  private Resource loaDocumentXlsDocument;

  @Value("${server.port}")
  private int definedServerPort;

  public InitializeLocal(
      AmazonDynamoDB amazonDynamoDB,
      DynamoDBMapper dynamoDBMapper,
      @Qualifier("localDocMgmtRestTemplate") RestTemplate localDocMgmtRestTemplate,
      Environment environment,
      CountriesRepository countriesRepository,
      WbUsersRepository wbUsersRepository) {
    this.amazonDynamoDB = amazonDynamoDB;
    this.dynamoDBMapper = dynamoDBMapper;
    this.localDocMgmtRestTemplate = localDocMgmtRestTemplate;
    this.environment = environment;
    this.countriesRepository = countriesRepository;
    this.wbUsersRepository = wbUsersRepository;
  }

  @Override
  public void run(String... args) throws InterruptedException, IOException {
    prepareRedis();
    prepareDynamoDBLocal();
    String[] activeProfiles = environment.getActiveProfiles();
    boolean isLocalProfileEnabled = false;
    for (String activeProfile : activeProfiles) {
      isLocalProfileEnabled = Constants.LOCAL_ENVIRONMENT.equals(activeProfile);
      if (isLocalProfileEnabled) {
        break;
      }
    }
    if (!isLocalProfileEnabled) {
      // Since security is enabled for local environment, we are not going to load data
      // as it will fail without bearer token.
      initializeLoaMetadataTable();
    }
    log.info("Local Loa Document Mgmt API started and ready to use.....");
  }

  private void prepareRedis() throws IOException {
    log.info("Deleting countries repository from  local redis");
    countriesRepository.deleteAll();
    log.info("Deleted countries repository from local redis successfully");
    log.info("Deleting wb users repository from local redis");
    wbUsersRepository.deleteAll();
    log.info("Deleted WBUsers repository from local redis successfully");
    log.info("Initializing local redis");
    LocalCountries localCountries =
        new ObjectMapper().readValue(localWbOfficesDataJsonFile.getFile(), LocalCountries.class);
    countriesRepository.saveAll(localCountries.getWbCountries());
    log.info("Local Redis initialized for countries");
    Optional<WbCountry> optionalWbCountry =
        countriesRepository.findByCode(Constants.DEFAULT_DOCUMENT_RESIDENCY_COUNTRY_CODE);
    Assert.isTrue(
        optionalWbCountry.isPresent(),
        "Local Redis Countries assertion failed - findByCode().isPresent assertion failed");
    Assert.notNull(
        optionalWbCountry.get(),
        "Local Redis Countries assertion failed - countriesRepository.findByCode().get() is null");
    log.info(
        "countryName for given countryCode {} is: {}",
        Constants.DEFAULT_DOCUMENT_RESIDENCY_COUNTRY_CODE,
        optionalWbCountry.get().getName());
    log.info(
        "Local Redis ready with countries and waiting for wb users to initialize.........................");

    LocalWbUsers localWbUsers =
        new ObjectMapper().readValue(localWbUsersDataJsonFile.getFile(), LocalWbUsers.class);
    wbUsersRepository.saveAll(localWbUsers.getWbUsers());
    log.info("Local Redis initialized for Wb Users");
    Optional<WbUser> optionalWbUser =
        wbUsersRepository.findBynnumber(documentManagementDefaultWbUser);
    Assert.isTrue(
        optionalWbUser.isPresent(),
        "Local Redis for Wb Users assertion failed - findBynnumber().isPresent assertion failed");
    Assert.notNull(
        optionalWbUser.get(),
        "Local Redis for Wb Users assertion failed - wbUsersRepository.findBynnumber().get() is null");
    log.info(
        "user name for given nnumber {} is: {}",
        documentManagementDefaultWbUser,
        optionalWbUser.get().getFullName());
    log.info(
        "user id for given nnumber {} is: {}",
        documentManagementDefaultWbUser,
        optionalWbUser.get().getId());
    log.info(
        "Local Redis Initialized and ready with both wb users and countries data......................");
  }

  private void prepareDynamoDBLocal() throws InterruptedException {
    deleteLoaMetadataTableIfExists();
    createLoaMetadataTableForLocalEnvironment(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata.class);
    createLoaMetadataTableForLocalEnvironment(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata.class);
  }

  private void deleteLoaMetadataTableIfExists() {
    try {
      amazonDynamoDB.deleteTable(dynamoDBPrefix + Constants.LOA_METADATA_DYNAMODB_TABLE);
      amazonDynamoDB.deleteTable(
          dynamoDBPrefix + Constants.LOA_METADATA_DYNAMODB_ARCHIVE_TABLE);
    } catch (ResourceNotFoundException resourceNotFoundException) {
      log.info(resourceNotFoundException.getMessage());
    }
  }

  private <T> void createLoaMetadataTableForLocalEnvironment(Class<T> entityName)
      throws InterruptedException {
    CreateTableRequest ctr =
        dynamoDBMapper
            .generateCreateTableRequest(entityName)
            .withProvisionedThroughput(new ProvisionedThroughput(1L, 1L));
    ctr.getGlobalSecondaryIndexes()
        .forEach(
            globalSecondaryIndex -> {
              globalSecondaryIndex.setProvisionedThroughput(new ProvisionedThroughput(1L, 1L));
              globalSecondaryIndex.setProjection(
                  new Projection().withProjectionType(ProjectionType.ALL));
            });
    boolean tableCreatedForLocalEnv = TableUtils.createTableIfNotExists(amazonDynamoDB, ctr);
    if (tableCreatedForLocalEnv) {
      log.info("Created table {}", ctr.getTableName());
      TableUtils.waitUntilActive(amazonDynamoDB, ctr.getTableName());
      log.info("Table {} is active", ctr.getTableName());
    }
  }

  private void initializeLoaMetadataTable() {
    String storeEndpoint1 =
        "http://localhost:" + definedServerPort + "/api/v1/loa/286412212/documents";
    String storeEndpoint2 =
        "http://localhost:" + definedServerPort + "/api/v1/loa/147853025/documents";

    ResponseEntity<com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse> loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint1,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentPdfDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                null,
                "2017-09-16",
                "Sample note -1",
                false,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId1 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint1,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentPptDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_1,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_2,
                Constants.LOCAL_USER_ID_2290,
                "2015-04-25",
                null,
                true,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId2 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint1,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentTxtDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_3,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_8,
                Constants.LOCAL_USER_ID_1822,
                "2016-05-15",
                null,
                true,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId3 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint1,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentPptxDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_2,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_4,
                null,
                "2012-09-01",
                "Sample note -10",
                false,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId4 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint1,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentDocxDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_2,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_5,
                Constants.LOCAL_USER_ID_2290,
                "2007-01-05",
                null,
                null,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId5 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint2,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentDocDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_2,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_7,
                Constants.LOCAL_USER_ID_1822,
                "2019-12-23",
                "Sample note - 4",
                null,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId6 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint2,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentXlsxDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_3,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_8,
                Constants.LOCAL_USER_ID_1822,
                "2020-03-21",
                null,
                false,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId7 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    loaDocumentStoreResponse =
        localDocMgmtRestTemplate.exchange(
            storeEndpoint2,
            HttpMethod.POST,
            prepareMetadataForDocuments(
                loaDocumentXlsDocument,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_2,
                Constants.LOCAL_CATEGORY_SUB_CATEGORY_ID_7,
                null,
                "2014-06-17",
                Constants.VERY_LONG_NOTES,
                null,
                null,
                null,
                null),
            com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store.LoaDocumentStoreResponse.class);

    String uniqueDocId8 =
        Objects.requireNonNull(loaDocumentStoreResponse.getBody())
            .getData()
            .getDocumentStore()
            .getUniqueDocId();

    String[] uniqueDocIds = {
      uniqueDocId1,
      uniqueDocId2,
      uniqueDocId3,
      uniqueDocId4,
      uniqueDocId5,
      uniqueDocId6,
      uniqueDocId7,
      uniqueDocId8
    };
    Assert.noNullElements(uniqueDocIds, "All store requests were processed successfully");
  }

  private static HttpEntity<MultiValueMap<String, Object>> prepareMetadataForDocuments(
      Resource document,
      Integer categoryId,
      Integer subCategoryId,
      Integer wbUserId,
      String receivedDate,
      String notes,
      Boolean nppi,
      String paymentDate,
      String checkEftNum,
      Boolean reissue) {
    MultiValueMap<String, Object> envoyStoreBody = new LinkedMultiValueMap<>();
    envoyStoreBody.add(Constants.LOA_MULTIPART_FILE_PARAMETER, document);
    envoyStoreBody.add(Constants.CATEGORY_ID_PARAMETER, categoryId);
    envoyStoreBody.add(Constants.SUB_CATEGORY_ID_PARAMETER, subCategoryId);
    envoyStoreBody.add(Constants.WB_USER_ID_PARAMETER, wbUserId);
    envoyStoreBody.add(Constants.RECEIVED_DATE_PARAMETER, receivedDate);
    envoyStoreBody.add(Constants.NOTES_PARAMETER, notes);
    envoyStoreBody.add(Constants.NPPI_PARAMETER, nppi);
    envoyStoreBody.add(Constants.PAYMENT_DATE_PARAMETER, paymentDate);
    envoyStoreBody.add(Constants.CHECK_EFT_NUM_PARAMETER, checkEftNum);
    envoyStoreBody.add(Constants.REISSUE_PARAMETER, reissue);

    MultiValueMap<String, String> envoyStoreHeader = new LinkedMultiValueMap<>();
    envoyStoreHeader.add("Content-Type", MediaType.MULTIPART_FORM_DATA_VALUE);

    return new HttpEntity<>(envoyStoreBody, envoyStoreHeader);
  }
}