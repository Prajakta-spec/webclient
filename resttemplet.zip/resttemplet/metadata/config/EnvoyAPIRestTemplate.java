package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class EnvoyAPIRestTemplate {

  @Value("${envoy.api.username}")
  private String envoyAPIUserName;

  @Value("${envoy.api.password}")
  private String envoyAPIPassword;

  @Value("${envoy.api.header.user-id.name}")
  private String envoyUserIdHeaderName;

  @Value("${envoy.api.header.user-id.value}")
  private String envoyUserIdHeaderValue;

  @Value("${envoy.api.header.public-key.name}")
  private String envoyPublicKeyHeaderName;

  @Value("${envoy.api.header.public-key.value}")
  private String envoyPublicKeyHeaderValue;

  @Bean("envoyRestTemplate")
  public RestTemplate envoyRestTemplate(RestTemplateBuilder restTemplateBuilder) {
    return restTemplateBuilder
        .basicAuthentication(envoyAPIUserName, envoyAPIPassword)
        .defaultHeader(envoyUserIdHeaderName, envoyUserIdHeaderValue)
        .defaultHeader(envoyPublicKeyHeaderName, envoyPublicKeyHeaderValue)
        .build();
  }
}
