package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.restore;

import org.springframework.stereotype.Service;

@Service
public class LoaRestoreMetadataService {

    public com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata restoreLoaMetadata(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata loaArchiveMetadata) {
        com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata();
        loaMetadata.setUniqueDocId(loaArchiveMetadata.getUniqueDocId());
        loaMetadata.setLoaId(loaArchiveMetadata.getLoaId());
        loaMetadata.setCategoryId(loaArchiveMetadata.getCategoryId());
        loaMetadata.setSubCategoryId(loaArchiveMetadata.getSubCategoryId());
        loaMetadata.setCreatedById(loaArchiveMetadata.getCreatedById());
        loaMetadata.setUpdatedById(loaArchiveMetadata.getUpdatedById());
        loaMetadata.setReceivedDate(loaArchiveMetadata.getReceivedDate());
        loaMetadata.setDocumentName(loaArchiveMetadata.getDocumentName());
        loaMetadata.setDocumentExtension(loaArchiveMetadata.getDocumentExtension());
        loaMetadata.setDocumentSizeInBytes(loaArchiveMetadata.getDocumentSizeInBytes());
        if (loaArchiveMetadata.getNotes() != null) {
            loaMetadata.setNotes(loaArchiveMetadata.getNotes());
        }
        if (loaArchiveMetadata.getNppi() != null) {
            loaMetadata.setNppi(loaArchiveMetadata.getNppi());
        }
        if(loaArchiveMetadata.getPaymentDate() != null) {
            loaMetadata.setPaymentDate(loaArchiveMetadata.getPaymentDate());
        }
        if(loaArchiveMetadata.getCheckEftNum() != null) {
            loaMetadata.setCheckEftNum(loaArchiveMetadata.getCheckEftNum());
        }
        if(loaArchiveMetadata.getReissue() != null) {
            loaMetadata.setReissue(loaArchiveMetadata.getReissue());
        }
        loaMetadata.setCreatedAt(loaArchiveMetadata.getCreatedAt());
        loaMetadata.setUpdatedAt(loaArchiveMetadata.getUpdatedAt());
        return loaMetadata;
    }
}
