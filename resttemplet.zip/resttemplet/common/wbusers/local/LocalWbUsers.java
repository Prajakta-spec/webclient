package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.local;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.wbusers.entity.WbUser;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@Getter
@Setter
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LocalWbUsers {

  private static final Logger LOGGER = LoggerFactory.getLogger(LocalWbUsers.class);

  @JsonProperty("users")
  private List<WbUser> wbUsers;
}