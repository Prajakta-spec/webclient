package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.IdpProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

@Configuration
@Profile({
  Constants.LOCAL_ENVIRONMENT,
  Constants.DEVELOPMENT_ENVIRONMENT,
  Constants.TEST_ENVIRONMENT,
  Constants.STAGING_ENVIRONMENT,
  Constants.PERFORMANCE_ENVIRONMENT,
  Constants.INTEGRATION_ENVIRONMENT,
  Constants.PRODUCTION_ENVIRONMENT
})
public class PingConfig {

  private final IdpProperties idpProperties;

  private final PingJwtProcessor pingJwtProcessor;

  public PingConfig(IdpProperties idpProperties, PingJwtProcessor pingJwtProcessor) {
    this.idpProperties = idpProperties;
    this.pingJwtProcessor = pingJwtProcessor;
  }

  @Bean
  public JwtDecoder pingJwtDecoder() {
    final NimbusJwtDecoder nimbusPingJwtDecoder = new NimbusJwtDecoder(pingJwtProcessor);
    nimbusPingJwtDecoder.setJwtValidator(createPingFederateJwtValidator());
    return nimbusPingJwtDecoder;
  }

  private DelegatingOAuth2TokenValidator<Jwt> createPingFederateJwtValidator() {
    final List<OAuth2TokenValidator<Jwt>> validators = new ArrayList<>();
    String[] allowedJWTAudiences = idpProperties.getPing().getAudience().split(",");
    List<String> allowedJWTAudiencesList = new ArrayList<>();
    for (String audience : allowedJWTAudiences) {
      allowedJWTAudiencesList.add(audience.trim());
    }
    HashSet<String> allowedJWTAudiencesSet = new HashSet<>(allowedJWTAudiencesList);
    validators.add(new JwtTimestampValidator());
    validators.add(new JwtIssuerValidator(Constants.PING_JWT_ISSUER));
    validators.add(new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.obligee.common.security.ping.PingJwtAudienceValidator(allowedJWTAudiencesSet));
    return new DelegatingOAuth2TokenValidator<>(validators);
  }
}
