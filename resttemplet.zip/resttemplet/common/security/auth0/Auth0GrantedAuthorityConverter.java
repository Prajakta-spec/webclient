package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.auth0;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.MediaType;
import org.springframework.lang.NonNull;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.*;

@Slf4j
public final class Auth0GrantedAuthorityConverter
    implements Converter<Jwt, Collection<GrantedAuthority>> {

  private final ObjectMapper objectMapper;

  private final String auth0ResourceServerName;

  private final boolean pullAuthorization;

  private final WebClient webClient;

  public Auth0GrantedAuthorityConverter(
      String auth0ResourceServerName, boolean pullAuthorization, WebClient webClient) {
    this.objectMapper = new ObjectMapper();
    this.auth0ResourceServerName = auth0ResourceServerName;
    this.pullAuthorization = pullAuthorization;
    this.webClient = webClient;
  }

  @Override
  public Collection<GrantedAuthority> convert(@NonNull Jwt jwt) {
    Collection<GrantedAuthority> grantedAuthorities = new ArrayList<>();
    for (String authority : getAuthorities(jwt)) {
      grantedAuthorities.add(new SimpleGrantedAuthority(authority));
    }
    if (log.isTraceEnabled()) {
      log.trace("grantedAuthorities: {}", grantedAuthorities);
    }
    log.info("*************User authenticating using AUTH0**************");
    return grantedAuthorities;
  }

  private Collection<String> getAuthorities(Jwt jwt) {
    List<String> resourceServerAuthoritiesList;
    Map<String, Object> authorities = jwt.getClaim(Constants.AUTH0_CLAIM_NAME);
    if (authorities == null || authorities.isEmpty()) {
      return Collections.emptyList();
    }
    Object resourceServerAuthoritiesObject = authorities.get(this.auth0ResourceServerName);
    if (resourceServerAuthoritiesObject == null) {
      return Collections.emptyList();
    }
    try {
      if (pullAuthorization) {
        String pullEntitlementsURL =
            objectMapper.readValue(
                objectMapper.writeValueAsString(resourceServerAuthoritiesObject), String.class);
        Map<String, List<String>> pullAuthorizationResponse =
            invokePullAuthorizationUrl(pullEntitlementsURL, jwt.getTokenValue());
        resourceServerAuthoritiesList = pullAuthorizationResponse.get(this.auth0ResourceServerName);
      } else {
        resourceServerAuthoritiesList =
            objectMapper.readValue(
                objectMapper.writeValueAsString(resourceServerAuthoritiesObject),
                new TypeReference<>() {});
      }
      if (resourceServerAuthoritiesList == null || resourceServerAuthoritiesList.isEmpty()) {
        return Collections.emptyList();
      } else {
        return resourceServerAuthoritiesList;
      }
    } catch (JsonProcessingException jsonProcessingException) {
      log.error(
          "JsonProcessingException thrown in : {} with message: {}",
          "Auth0GrantedAuthorityConverter.getAuthorities(Jwt jwt)",
          jsonProcessingException.getMessage());
      return Collections.emptyList();
    }
  }

  private Map<String, List<String>> invokePullAuthorizationUrl(
      String pullAuthorizationUrl, String accessToken) {
    return this.webClient
        .get()
        .uri(pullAuthorizationUrl)
        .headers(httpHeaders -> httpHeaders.setBearerAuth(accessToken))
        .accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(new ParameterizedTypeReference<Map<String, List<String>>>() {})
        .block();
  }
}
