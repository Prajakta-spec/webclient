package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception;

import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class LoaDocumentCategoriesClientException extends Exception {

  private static final Logger logger =
      LoggerFactory.getLogger(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.category.exception.LoaDocumentCategoriesClientException.class);

  private final HttpStatus httpStatusCode;

  public LoaDocumentCategoriesClientException(HttpStatus httpStatusCode, String message) {
    super(message);
    this.httpStatusCode = httpStatusCode;
  }
}