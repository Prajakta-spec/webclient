package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.config;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.RequestEntity;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProvider;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientProviderBuilder;
import org.springframework.security.oauth2.client.endpoint.DefaultClientCredentialsTokenResponseClient;
import org.springframework.security.oauth2.client.endpoint.OAuth2AccessTokenResponseClient;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequest;
import org.springframework.security.oauth2.client.endpoint.OAuth2ClientCredentialsGrantRequestEntityConverter;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.DefaultOAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.OAuth2AuthorizedClientRepository;
import org.springframework.util.MultiValueMap;

/**
 * OAuth2 configuration for Envoy client credentials authentication.
 * Supports separate audiences for read and write operations.
 */
@Configuration
@Profile({
    Constants.LOCAL_ENVIRONMENT,
    Constants.DEVELOPMENT_ENVIRONMENT,
    Constants.TEST_ENVIRONMENT,
    Constants.STAGING_ENVIRONMENT,
    Constants.PRODUCTION_ENVIRONMENT
})
public class EnvoyOAuth2Config {

    @Value("${envoy.oauth2.write.audience:}")
    private String envoyWriteAudience;

    @Value("${envoy.oauth2.read.audience:}")
    private String envoyReadAudience;

    /**
     * Creates an OAuth2 authorized client manager with custom token response client
     * that includes audience parameter for Envoy authentication.
     *
     * @param clientRegistrationRepository the client registration repository
     * @param authorizedClientRepository   the authorized client repository
     * @return configured OAuth2AuthorizedClientManager
     */
    @Bean
    public OAuth2AuthorizedClientManager authorizedClientManager(
            ClientRegistrationRepository clientRegistrationRepository,
            OAuth2AuthorizedClientRepository authorizedClientRepository) {

        // Create custom token response client that includes audience parameter
        OAuth2AccessTokenResponseClient<OAuth2ClientCredentialsGrantRequest> accessTokenResponseClient =
                createClientCredentialsTokenResponseClient();

        OAuth2AuthorizedClientProvider authorizedClientProvider =
                OAuth2AuthorizedClientProviderBuilder.builder()
                        .clientCredentials(configurer ->
                                configurer.accessTokenResponseClient(accessTokenResponseClient))
                        .build();

        DefaultOAuth2AuthorizedClientManager authorizedClientManager =
                new DefaultOAuth2AuthorizedClientManager(
                        clientRegistrationRepository,
                        authorizedClientRepository);

        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        return authorizedClientManager;
    }

    /**
     * Creates a custom OAuth2 access token response client that adds audience parameter
     * based on the client registration ID (read vs write operations).
     *
     * @return configured OAuth2AccessTokenResponseClient
     */
    private OAuth2AccessTokenResponseClient<OAuth2ClientCredentialsGrantRequest> createClientCredentialsTokenResponseClient() {
        DefaultClientCredentialsTokenResponseClient tokenResponseClient =
                new DefaultClientCredentialsTokenResponseClient();

        // Customize the request entity converter to add audience parameter
        tokenResponseClient.setRequestEntityConverter(grantRequest -> {
            OAuth2ClientCredentialsGrantRequestEntityConverter converter =
                    new OAuth2ClientCredentialsGrantRequestEntityConverter();
            RequestEntity<?> entity = converter.convert(grantRequest);

            // Extract existing parameters
            MultiValueMap<String, String> parameters =
                    (MultiValueMap<String, String>) entity.getBody();

            // Determine audience based on client registration ID
            String registrationId = grantRequest.getClientRegistration().getRegistrationId();
            String audience = determineAudienceForRegistration(registrationId);

            if (audience != null) {
                parameters.add("aud", audience);
            }

            // Create new request entity with updated parameters
            return new RequestEntity<>(
                    parameters,
                    entity.getHeaders(),
                    entity.getMethod(),
                    entity.getUrl());
        });

        return tokenResponseClient;
    }

    /**
     * Determines the appropriate audience based on the client registration ID.
     *
     * @param registrationId the OAuth2 client registration ID
     * @return the audience URL for the given registration, or null if not found
     */
    private String determineAudienceForRegistration(String registrationId) {
        if (Constants.ENVOY_WRITE_CLIENT_REGISTRATION_ID.equals(registrationId)
                && envoyWriteAudience != null && !envoyWriteAudience.isEmpty()) {
            return envoyWriteAudience;
        } else if (Constants.ENVOY_READ_CLIENT_REGISTRATION_ID.equals(registrationId)
                && envoyReadAudience != null && !envoyReadAudience.isEmpty()) {
            return envoyReadAudience;
        }
        return null;
    }
}
