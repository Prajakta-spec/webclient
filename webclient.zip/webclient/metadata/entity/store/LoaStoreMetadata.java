package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.store;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class LoaStoreMetadata {

  @NotBlank(message = "uniqueDocId is required")
  private String uniqueDocId;

  @NotNull(message = "categoryId is required")
  @Positive(message = Constants.CATEGORY_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer categoryId;

  @NotNull(message = "subCategoryId is required")
  @Positive(message = Constants.SUB_CATEGORY_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer subCategoryId;

  @Positive(message = Constants.CREATED_BY_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer createdById;

  @Positive(message = Constants.UPDATED_BY_ID_PATCH_GREATER_THAN_ZERO_MSG)
  private Integer updatedById;

  @Pattern(
      regexp = Constants.REGEX_RECEIVED_DATE_PARAMETER,
      message = Constants.INVALID_RECEIVED_DATE_PATCH_MESSAGE)
  private String receivedDate;

  @NotBlank(message = "documentName is required")
  private String documentName;

  private Double documentSizeInBytes;

  @Pattern(
      regexp = Constants.REGEX_RECEIVED_DATE_PARAMETER,
      message = Constants.INVALID_PAYMENT_DATE_PATCH_MESSAGE)
  private String paymentDate;

  private String checkEftNum;

  private Boolean reissue;

  private Boolean nppi;

  private String notes;
}