package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb;

import com.amazonaws.services.dynamodbv2.datamodeling.DynamoDBIndexHashKey;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
public class LoaId implements Serializable {

  @DynamoDBIndexHashKey(
      globalSecondaryIndexNames = {
        "idx_global_obligee_id_order_received_date",
        "idx_global_category_id_and_obligee_id",
        "idx_global_sub_category_id_and_obligee_id",
        "idx_global_created_by_id_and_obligee_id",
        "idx_global_updated_by_id_and_obligee_id"
      },
      attributeName = "obligee_id")
  private Integer id;
}