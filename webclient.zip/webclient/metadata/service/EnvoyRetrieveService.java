package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyClientException;
import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.exception.EnvoyServerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@Service
public class EnvoyRetrieveService {

  private static final Logger LOGGER = LoggerFactory.getLogger(EnvoyRetrieveService.class);

  private final WebClient envoyReadWebClient;

  @Value("${envoy.retrieve.content.api.endpoint}")
  private String envoyRetrieveEndpoint;

  public EnvoyRetrieveService(@Qualifier("envoyReadWebClient") WebClient envoyReadWebClient) {
    this.envoyReadWebClient = envoyReadWebClient;
  }

  public Resource retrieveLoaDocuments(String trackingId, String uniqueDocId)
      throws EnvoyClientException, EnvoyServerException {
    LOGGER.info("{} - Enter EnvoyRetrieveService.retrieveLoaDocuments()", trackingId);

    String retrieveContentAPI = envoyRetrieveEndpoint + uniqueDocId + "/native";

    try {
      Resource response =
          envoyReadWebClient
              .get()
              .uri(retrieveContentAPI)
              .retrieve()
              .bodyToMono(Resource.class)
              .block();

      LOGGER.info("{} - Exit EnvoyRetrieveService.retrieveLoaDocuments()", trackingId);
      return response;

    } catch (WebClientResponseException webClientResponseException) {
      if (webClientResponseException.getStatusCode().is4xxClientError()) {
        LOGGER.error(
            "{} - Envoy Retrieve Content API {} threw a WebClientResponseException with the http status code: {} "
                + "and a body {}",
            trackingId,
            retrieveContentAPI,
            webClientResponseException.getStatusCode(),
            webClientResponseException.getResponseBodyAsString());
        throw new EnvoyClientException(
            HttpStatus.valueOf(webClientResponseException.getStatusCode().value()),
            webClientResponseException.getResponseBodyAsString());
      } else {
        LOGGER.error(
            "{} - Envoy Retrieve Content API {} threw a WebClientResponseException with the http status code: {} "
                + "and a body {}",
            trackingId,
            retrieveContentAPI,
            webClientResponseException.getStatusCode(),
            webClientResponseException.getResponseBodyAsString());
        throw new EnvoyServerException(
            HttpStatus.valueOf(webClientResponseException.getStatusCode().value()),
            webClientResponseException.getResponseBodyAsString());
      }
    }
  }
}
