package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.service.archive;

import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class LoaArchiveMetadataService {

  public com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata createLoaArchiveMetadata(com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaMetadata loaMetadata, Integer deletedById) {
    com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata loaArchiveMetadata = new com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.loa.metadata.entity.dynamodb.LoaArchiveMetadata();
    loaArchiveMetadata.setUniqueDocId(loaMetadata.getUniqueDocId());
    loaArchiveMetadata.setLoaId(loaMetadata.getLoaId());
    loaArchiveMetadata.setCategoryId(loaMetadata.getCategoryId());
    loaArchiveMetadata.setSubCategoryId(loaMetadata.getSubCategoryId());
    loaArchiveMetadata.setCreatedById(loaMetadata.getCreatedById());
    loaArchiveMetadata.setUpdatedById(loaMetadata.getUpdatedById());
    loaArchiveMetadata.setDeletedById(deletedById);
    loaArchiveMetadata.setReceivedDate(loaMetadata.getReceivedDate());
    loaArchiveMetadata.setDocumentName(loaMetadata.getDocumentName());
    loaArchiveMetadata.setDocumentExtension(loaMetadata.getDocumentExtension());
    loaArchiveMetadata.setDocumentSizeInBytes(loaMetadata.getDocumentSizeInBytes());
    if (loaMetadata.getPaymentDate() != null) {
      loaArchiveMetadata.setPaymentDate(loaMetadata.getPaymentDate());
    }
    if (loaMetadata.getNotes() != null) {
      loaArchiveMetadata.setNotes(loaMetadata.getNotes());
    }
    if (loaMetadata.getNppi() != null) {
      loaArchiveMetadata.setNppi(loaMetadata.getNppi());
    }
    if (loaMetadata.getCheckEftNum() != null) {
      loaArchiveMetadata.setCheckEftNum(loaMetadata.getCheckEftNum());
    }
    if (loaMetadata.getReissue() != null) {
      loaArchiveMetadata.setReissue(loaMetadata.getReissue());
    }
    loaArchiveMetadata.setCreatedAt(loaMetadata.getCreatedAt());
    loaArchiveMetadata.setUpdatedAt(loaMetadata.getUpdatedAt());
    loaArchiveMetadata.setDeletedAt(new Date());
    return loaArchiveMetadata;
  }
}