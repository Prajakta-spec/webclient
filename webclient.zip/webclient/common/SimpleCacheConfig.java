package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common;

import org.springframework.cache.CacheManager;
import org.springframework.cache.concurrent.ConcurrentMapCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SimpleCacheConfig {

  @Bean("simpleCacheManager")
  public CacheManager simpleCacheManager() {
    return new ConcurrentMapCacheManager("obligeeDocumentCategories", "loaDocumentCategories");
  }
}