package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

import java.net.URL;

@Getter
@Setter
@Validated
@ConfigurationProperties(prefix = "lmig.grs.surety.idp.oauth2")
public class IdpProperties {

  private Ping ping = new Ping();
  private Auth0 auth0 = new Auth0();

  @Getter
  @Setter
  public static class Ping {
    @NotEmpty private String audience;

    @NotNull private URL signingCertUri;
  }

  @Getter
  @Setter
  public static class Auth0 {
    @NotEmpty private String issuerUri;

    @NotEmpty private String resourceServerName;

    private boolean pullAuthorization;
  }
}