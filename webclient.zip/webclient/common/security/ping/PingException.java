package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.security.ping;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PingException extends Exception {

  public PingException(final String message, final Throwable cause) {
    super(message, cause);
  }
}