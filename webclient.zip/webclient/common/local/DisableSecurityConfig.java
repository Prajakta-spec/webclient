package com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.local;

import com.lmig.globalspecialty.surety.grsindividualdocmgmtapi.common.constants.Constants;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;

import static org.springframework.security.config.Customizer.withDefaults;

@EnableWebSecurity
@Profile({Constants.LOCAL_DOCKER_ENVIRONMENT, Constants.INTEGRATION_TEST_ENVIRONMENT})
@Configuration
public class DisableSecurityConfig {

  @Bean
  public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
    http.cors(withDefaults())
        .authorizeHttpRequests(
            authorizeHttpRequests ->
                authorizeHttpRequests
                    .requestMatchers(HttpMethod.OPTIONS, "/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.GET, "/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.PATCH, "/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.POST, "/**")
                    .permitAll()
                    .requestMatchers(HttpMethod.DELETE, "/**")
                    .permitAll());
    return http.build();
  }

  @Bean
  public WebSecurityCustomizer webSecurityCustomizer() {
    return (web) -> web.ignoring().requestMatchers("/**");
  }
}